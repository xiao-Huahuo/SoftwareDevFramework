# 第3次课学生起始工程（GoF重构版）

正式模式：Strategy、Template Method、State。

## 运行基线系统

1. 在IDE中运行启动类：
   `edu.course.library.Class03Application`
2. 或在项目根目录执行：

   ```bash
   mvn compile
   java -cp target/classes edu.course.library.Class03Application
   ```

程序会完成一次普通学生借阅，输出借阅前后图书状态、借期和通知次数。
这个入口只展示重构前的基线行为，不包含三个模式任务的实现答案。

## 运行基线测试

执行 `mvn test`，确认现有功能通过后，再按学生任务单完成A、B、C三个连续任务。
