package edu.course.library;

/**
 * 第3次课起始工程的运行入口。
 *
 * <p>这里仅组装并运行重构前的基线系统，便于先观察现有行为；
 * Strategy、Template Method 和 State 的实现由后续实践任务完成。</p>
 */
public final class Class03Application {
    private Class03Application() {
    }

    public static void main(String[] args) {
        InMemoryBorrowRepository repository = new InMemoryBorrowRepository();
        FakeNotifier notifier = new FakeNotifier();

        User reader = new User("S001", UserType.STUDENT);
        BookCopy book = new BookCopy("B001", false);
        repository.add(reader);
        repository.add(book);

        BorrowApplicationService service = new BorrowApplicationService(
                repository,
                notifier,
                new BorrowPolicy()
        );

        System.out.println("=== Class 03: Library baseline ===");
        System.out.println("Reader: " + reader.id() + " (" + reader.type() + ")");
        System.out.println("Book status before borrowing: " + book.status());

        service.borrow(reader.id(), book.id());
        BorrowRecord record = repository.lastRecord();

        System.out.println("Borrowed: " + record.userId() + " -> " + record.bookId());
        System.out.println("Loan period: " + record.loanDays() + " days");
        System.out.println("Book status after borrowing: " + book.status());
        System.out.println("Notification count: " + notifier.count());
    }
}
