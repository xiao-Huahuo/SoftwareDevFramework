package edu.course.library;

public class BookCopy {
    private final String id;
    private final boolean restricted;
    private BookStatus status = BookStatus.AVAILABLE;

    public BookCopy(String id, boolean restricted) {
        this.id = id;
        this.restricted = restricted;
    }

    public String id() {
        return id;
    }

    public boolean restricted() {
        return restricted;
    }

    public BookStatus status() {
        return status;
    }

    public void borrow() {
        switch (status) {
            case AVAILABLE, RESERVED -> status = BookStatus.ON_LOAN;
            default -> throw new IllegalStateException("CANNOT_BORROW");
        }
    }

    public void reserve() {
        if (status != BookStatus.ON_LOAN) throw new IllegalStateException("CANNOT_RESERVE");
        status = BookStatus.RESERVED;
    }

    public void startMaintenance() {
        if (status != BookStatus.AVAILABLE) throw new IllegalStateException("CANNOT_MAINTAIN");
        status = BookStatus.MAINTENANCE;
    }

    public void restore() {
        switch (status) {
            case ON_LOAN, RESERVED, MAINTENANCE -> status = BookStatus.AVAILABLE;
            default -> throw new IllegalStateException("CANNOT_RESTORE");
        }
    }
}