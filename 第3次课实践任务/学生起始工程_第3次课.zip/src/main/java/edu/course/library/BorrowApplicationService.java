package edu.course.library;

public class BorrowApplicationService {
    private final BorrowRepository repo;
    private final Notifier notifier;
    private final BorrowPolicy policy;

    public BorrowApplicationService(BorrowRepository r, Notifier n, BorrowPolicy p) {
        repo = r;
        notifier = n;
        policy = p;
    }

    public void borrow(String userId, String bookId) {
        User u = repo.findUser(userId);
        BookCopy b = repo.findBook(bookId);
        if (u == null || b == null) throw new IllegalArgumentException("NOT_FOUND");
        int days = policy.loanDays(u, b, repo.activeCount(userId));
        b.borrow();
        repo.save(new BorrowRecord(userId, bookId, days));
        notifier.notify(u, "BORROW:" + bookId);
    }
}