package edu.course.library;
public class BorrowPolicy {
 public int loanDays(User u,BookCopy b,long active){ int limit=u.type()==UserType.TEACHER?10:5; int days=u.type()==UserType.TEACHER?90:30; if(active>=limit) throw new IllegalStateException("LIMIT"); if(b.restricted()&&u.type()!=UserType.TEACHER) throw new IllegalStateException("RESTRICTED"); return days; }
}